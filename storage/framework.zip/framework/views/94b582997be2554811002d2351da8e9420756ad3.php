 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Peserta bioscope</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Status</th>
                                            <th>Region</th>
                                            <th>Email</th>
                                            <th>No. Handphone</th>
                                            <th>Detail</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Status</th>
                                            <th>Region</th>
                                            <th>Email</th>
                                            <th>No. Handphone</th>
                                            <th>Detail</th>                                       
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($p->user->name); ?></td>
                                            <td> <button id="status<?php echo e($i); ?>" class="badge btn"><?php echo e($p->user->pembayaran); ?></button></td>
                                            <td><?php echo e($p->cabang); ?></td>
                                            <td><?php echo e($p->email1); ?></td>
                                            <td><?php echo e($p->telepon1); ?></td>
                                            <td>
                                                <a class="btn btn-info" href="" data-toggle="modal" data-target="#detail<?php echo e($p->id); ?>">
                                                Show
                                                </a>
                                            </td>
                                        </tr>
                                        <script type="text/javascript">
                                            if ('<?php echo e($p->user->pembayaran); ?>' == 'Belum Bayar') {
                                                var belum = document.getElementById('status<?php echo e($i); ?>');
                                                belum.classList.add('badge-danger');
                                            } else if ('<?php echo e($p->user->pembayaran); ?>' == 'Sudah Bayar') {
                                                var sudah = document.getElementById('status<?php echo e($i); ?>');
                                                sudah.classList.add('badge-success');
                                            } else {
                                                var none = document.getElementById('status<?php echo e($i); ?>');
                                                none.classList.add('badge-warning');
                                            }

                                        </script>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
                <!-- detaile -->
                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal fade" id="detail<?php echo e($p->id); ?>" tabindex="-99" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($p->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable" role="document" width="80%">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Biodata Peserta</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                      <table>
                                                        <tr>
                                                            <td>Sekolah</td>
                                                            <td>: <?php echo e($p->sekolah1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Cabang Lomba</td>
                                                            <td>: <?php echo e($p->cabang); ?></td>
                                                        </tr>
                                                        <tr></tr>
                                                        <tr>
                                                            <td>Nama Ketua</td>
                                                            <td>: <?php echo e($p->nama1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($p->kelas1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($p->alamat1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($p->telepon1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($p->line1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($p->email1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>foto</td>
                                                            <td>: <img src="<?php echo e(asset('storage/foto/'.$p->foto1)); ?>" width="300px"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>kartu</td>
                                                            <td>: <img src="<?php echo e(asset('storage/kartu/'.$p->kartu1)); ?>" width="300px"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Nama anggota</td>
                                                            <td>: <?php echo e($p->nama2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sekolah</td>
                                                            <td>: <?php echo e($p->sekolah2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($p->kelas2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($p->alamat2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($p->telepon2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($p->line2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($p->email2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>foto</td>
                                                            <td>: <img src="<?php echo e(asset('storage/foto/'.$p->foto2)); ?>" width="300px"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>kartu</td>
                                                            <td>: <img src="<?php echo e(asset('storage/kartu/'.$p->kartu2)); ?>" width="300px"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Nama anggota</td>
                                                            <td>: <?php echo e($p->nama3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sekolah</td>
                                                            <td>: <?php echo e($p->sekolah3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($p->kelas3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($p->alamat3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($p->telepon3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($p->line3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($p->email3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>foto</td>
                                                            <td>: <img src="<?php echo e(asset('storage/foto/'.$p->foto3)); ?>" width="300px"></td>
                                                        </tr>
                                                        <tr>
                                                            <td>kartu</td>
                                                            <td>: <img src="<?php echo e(asset('storage/kartu/'.$p->kartu3)); ?>" width="300px"></td>
                                                        </tr>
                                                      </table>  
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/peserta/data-peserta.blade.php ENDPATH**/ ?>