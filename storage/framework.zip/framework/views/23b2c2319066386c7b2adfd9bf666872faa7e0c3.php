<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($data->nama1); ?></title>
    <style>
        .page-break {
            page-break-before: always;
        }
        .kartu {
            width: 200px; height:150px; position: absolute; top: 500px; left: 0;
        }
        .foto {
            width: 150px; height:200px; position: absolute; top: 500px; right: 0; border: 3px solid black;
        }
    </style>
</head>
<body>
        <h1 style = "margin-left: 50px;">Kartu Peserta Bioscope 2021</h1><hr><hr>
        <table>
                                                        <tr>
                                                            <td>Nama</td>
                                                            <td>: <?php echo e($data->nama1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Domisili</td>
                                                            <td>: <?php echo e($data->domisili1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($data->kelas1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($data->alamat1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($data->telepon1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($data->line1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($data->email1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <img src="data:image/png;base64,<?php echo e($data->foto1?base64_encode(file_get_contents(public_path('storage/foto/'.$data->foto1))):''); ?>" class="foto"><br><img src="data:image/png;base64,<?php echo e($data->kartu1?base64_encode(file_get_contents(public_path('storage/kartu/'.$data->kartu1))):''); ?>" class="kartu"></td>
                                                        </tr>
                                                        </table>
                                                        <div class="page-break"></div>
                                                        <h1 style = "margin-left: 50px;">Kartu Peserta Bioscope 2021</h1><hr><hr>
                                                        <table>
                                                        <tr>
                                                            <td>Nama</td>
                                                            <td>: <?php echo e($data->nama2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Domisili</td>
                                                            <td>: <?php echo e($data->domisili2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($data->kelas2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($data->alamat2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($data->telepon2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($data->line2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($data->email2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <img src="data:image/png;base64,<?php echo e($data->foto2?base64_encode(file_get_contents(public_path('storage/foto/'.$data->foto2))):''); ?>" class="foto"><br><img src="data:image/png;base64,<?php echo e($data->kartu2?base64_encode(file_get_contents(public_path('storage/kartu/'.$data->kartu2))):''); ?>" class="kartu"></td>
                                                        </tr>
                                                        </table>
                                                        <div class="page-break"></div>
                                                        <h1 style = "margin-left: 50px;">Kartu Peserta Bioscope 2021</h1><hr><hr>
                                                        <table>
                                                        <tr>
                                                            <td>Nama</td>
                                                            <td>: <?php echo e($data->nama3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Domisili</td>
                                                            <td>: <?php echo e($data->domisili3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($data->kelas3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($data->alamat3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($data->telepon3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($data->line3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($data->email3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <img src="data:image/png;base64,<?php echo e($data->foto3?base64_encode(file_get_contents(public_path('storage/foto/'.$data->foto3))):''); ?>" class="foto"><br><img src="data:image/png;base64,<?php echo e($data->kartu3?base64_encode(file_get_contents(public_path('storage/kartu/'.$data->kartu3))):''); ?>" class="kartu"></td>
                                                        </tr>
                                                      </table>'
</body>
</html><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/template.blade.php ENDPATH**/ ?>