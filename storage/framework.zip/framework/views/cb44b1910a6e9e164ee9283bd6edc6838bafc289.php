 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">
                	<?php if(session('success')): ?>
	                <div class="alert alert-success">
	                    <?php echo e(session('success')); ?>

	                </div>
	                <?php endif; ?>
	                <?php if(session('update')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('update')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session('delete')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('delete')); ?>

                    </div>
                    <?php endif; ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Soal bioscope</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Gambar</th>
                                            <th>Soal</th>
                                            <th>Detail</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Gambar</th>
                                            <th>Soal</th>
                                            <th>Detail</th>
                                            <th>Aksi</th>                      
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        	<td><?php echo e($i); ?></td>
                                            <td><img src="<?php echo e(url('storage/gambar/' . $p->gambar)); ?>" width="150px"  alt="<?php echo e($p->gambar); ?>"></td>
                                            <td><?php echo e(strip_tags($p->soal)); ?></td>
                                            <td>
                                                <a class="btn btn-info" data-toggle="modal" data-target="#detail<?php echo e($p->id); ?>">Show</a>
                                            </td>
                                            <td>
                                            	<form method="GET" action="<?php echo e(url('soal/edit/'.$p->id)); ?>">
                                                <button class="btn badge badge-warning p-2">Edit</button>
                                                </form>
                                                <hr>
                                                <a class="btn badge badge-danger p-2" data-toggle="modal" data-target="#deleteModal<?php echo e($p->id); ?>">Delete</a>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="modal fade" id="detail<?php echo e($p->id); ?>" tabindex="-99" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($p->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable" role="document" width="80%">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Soal</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                      <table>
                                                        <div class="form-group">
                                                            <label for="soal">gambar :</label>
                                                            <div id="soal"><img src="<?php echo e(url('storage/gambar/' . $p->gambar)); ?>" alt="<?php echo e($p->gambar); ?>" width="150px"></div>
                                                        </div>
                                                        <tr>
                                                        	<td colspan="2" class="justify-middle">
                                                        		
                                                        	</td>
                                                        </tr>
                                                        <div class="form-group">
                                                            <label for="soal">Soal :</label>
                                                            <div id="soal"><?php echo $p->soal; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Pilihan A :</label>
                                                            <div id="soal"><?php echo $p->opsi_a; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Pilihan B :</label>
                                                            <div id="soal"><?php echo $p->opsi_b; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Pilihan C :</label>
                                                            <div id="soal"><?php echo $p->opsi_c; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Pilihan D :</label>
                                                            <div id="soal"><?php echo $p->opsi_d; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Pilihan E :</label>
                                                            <div id="soal"><?php echo $p->opsi_e; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Kunci :</label>
                                                            <div id="soal"><?php echo $p->kunjaw; ?></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="soal">Waktu :</label>
                                                            <div id="soal"><?php echo $p->waktu; ?></div>
                                                        </div>
                                                      </table>  
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
	<!-- Sure Modal-->
    <div class="modal fade" id="deleteModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Delete?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Delete" below if you are ready to delete your current question.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <form action="<?php echo e(url('soal/'.$p->id)); ?>" method="POST">
                    <button class=" btn btn-danger">Delete</button>
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/soal/index.blade.php ENDPATH**/ ?>