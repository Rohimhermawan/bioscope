
<?php $__env->startSection('content'); ?>
<div class="container bg-white py-4" style="border-radius: 3px; margin-top: 100px;">
	<div>
	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis totam incidunt numquam! Quas a exercitationem tenetur voluptates, qui quis deserunt laudantium expedita, debitis iste illum soluta maiores. Sed architecto illo autem. Reprehenderit veniam saepe ducimus quisquam maiores dolorem asperiores? Tempore necessitatibus quidem odit temporibus quis saepe harum et officiis itaque consectetur ex mollitia, quos soluta in vitae! Ex non ab aspernatur quia officia? Omnis perspiciatis optio illum pariatur ea est non ipsa maxime quaerat? Officiis minus deleniti neque id commodi perspiciatis, provident non architecto. Pariatur autem hic accusantium quam quo. Quis nobis nam repudiandae a eveniet ea obcaecati nesciunt. Harum!
	</div>
	<div class="col-md-10 pt-5" style="margin: auto;" id="bayar">
		<div>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
		<form method="POST" action="<?php echo e(url('home/'.$user->id)); ?>">
			<?php echo csrf_field(); ?>
			<div class="form-group">
	                    <label for="sekolah">Asal Sekolah</label>
	                    <input type="text" class="form-control <?php $__errorArgs = ['sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sekolah" placeholder="e.g : SMAN X Bandung" id="sekolah1" value="<?php echo e(old('sekolah')); ?>">
	                </div>
			<div class="form-group" >
                <label for="genre" class="form-label">Cabang Lomba</label>
                    <select class="form-select" id="genre" aria-label="Default select example" name="cabang">
                        <option selected>Pilih Jenis Lomba</option>
                        <option value="Poster">Poster</option>
                        <option value="Essay">Essay</option>
                        <option value="Olimpiade">Olimpiade</option>
                    </select>
             </div>
			<?php $__errorArgs = ['cabang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		    <div class="alert alert-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             <div class="form-group">
                <label for="pengirim">Bank Pengirim</label>
	            <input type="input" class="form-control <?php $__errorArgs = ['pengirim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pengirim" placeholder="" id="pengirim">
	        </div>
			<?php $__errorArgs = ['pengirim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		    <div class="alert alert-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>				
	        <div class="form-group" >
                <label for="banktujuan" class="form-label">Bank Tujuan</label>
                    <select class="form-select" id="genre" aria-label="Default select example" name="penerima">
                        <option selected>Pilih Jenis Bank</option>
                        <option value="BNI">BNI</option>
                        <option value="Mandiri">Mandiri</option>
                        <option value="BJB">BJB</option>
                    </select>
             </div>
			<?php $__errorArgs = ['bukti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		    <div class="alert alert-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	        <button type="submit" class="btn btn-success mt-3">Upload</button>
		</form>
	</div>
	<div id="uploadBukti" hidden>
		<p>
		<ul>Nama : <?php echo e($user->name??'--'); ?></ul>
		<ul>Sekolah : <?php echo e($user->participant->first()->sekolah??'--'); ?></ul>  
		<ul>Cabang : <?php echo e($user->participant->first()->cabang??'--'); ?></ul>
		<br>lakukan pembayaran dari bank <i><?php echo e($user->participant->first()->pengirim??'--'); ?></i> ke <i><?php echo e($user->participant->first()->penerima??'--'); ?></i> sebanyak <b id="early">Rp sekian</b> <b id="late" hidden>Rp segitu</b> <b id="essay" hidden>Rp sakitu</b> <b id="Poster" hidden>Rp sakieu</b>

		<form action="<?php echo e(url('home/upload/'.$user->id)); ?>" method="POST" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<div class="form-group">
            <label for="bukti">Masukkan Bukti Pembayaran</label>
	        <input type="file" class="form-control <?php $__errorArgs = ['bukti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bukti" placeholder="" id="bukti">
	    </div>
		<button type="submit" class="btn btn-success mt-3">Upload</button>
		</form>
		</p>
	</div>
	<div class="col-md-10" style="margin: auto;" id="sukses" hidden>
		<h3>Bukti Pembayaran Berhasil Diupload</h3>
		<p>Terimakasih, bukti pembayaran sedang kami proses. Mohon tunggu validasi akun selambat-lambatnya 3x24 jam. Validasi akun akan diberitahukan melalui email yang terdaftar pada website. Apabila lebih dari 3x24 jam, akun peserta belum tervalidasi, peserta dapat menghubungi narahubung di bawah ini :</p>
	</div>
	<div class="col-md-10" style="margin: auto;" id="konfirm" hidden>
		<h3>Bukti Pembayaran Berhasil Diupload</h3>
		<p>Terimakasih, bukti pembayaran sudah kami proses. Silakan mengerjakan test sesuai waktu yang telah ditentukan</p>
	</div>
</div>
<script type="text/javascript">
	var	bayar = document.getElementById('bayar');
	var sukses = document.getElementById('sukses');
	var konfirm = document.getElementById('konfirm');
	var early = document.getElementById("early");
	var late = document.getElementById('late');
	var essay = document.getElementById('essay');
	var poster = document.getElementById('Poster');
	var upload = document.getElementById('uploadBukti')
	if ('<?php echo e($user->participant->first()->cabang??false); ?>') {
		upload.removeAttribute("hidden");
		bayar.setAttribute("hidden", "");
		sukses.setAttribute("hidden", "");
		konfirm.setAttribute("hidden", "");
	}
	lateDate = new Date('May 28, 2021').getTime();
	now = new Date().getTime();
	if (now >= lateDate) {
		early.setAttribute("hidden", "");
		poster.setAttribute("hidden", "");
		essay.setAttribute("hidden", "");
		late.removeAttribute("hidden");
	}
	if ('<?php echo e($user->participant->first()->cabang??false); ?>' == 'Essay') {
		early.setAttribute("hidden", "");
		poster.setAttribute("hidden", "");
		late.setAttribute("hidden", "");
		essay.removeAttribute("hidden");
	}
	if ('<?php echo e($user->participant->first()->cabang??false); ?>' == 'Poster') {
		early.setAttribute("hidden", "");
		late.setAttribute("hidden", "");
		essay.setAttribute("hidden", "");
		poster.removeAttribute("hidden");
	}
	if ('<?php echo e($user->pembayaran); ?>' == 'Menunggu konfirmasi') {
		bayar.setAttribute("hidden", "");
		upload.setAttribute("hidden", "");
		sukses.removeAttribute("hidden");
	}
	
	if ('<?php echo e($user->pembayaran); ?>' == 'Sudah Bayar') {
		bayar.setAttribute("hidden", "");
		sukses.setAttribute("hidden", "");
		upload.setAttribute("hidden", "");
		konfirm.removeAttribute("hidden");
	}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/user/pembayaran.blade.php ENDPATH**/ ?>