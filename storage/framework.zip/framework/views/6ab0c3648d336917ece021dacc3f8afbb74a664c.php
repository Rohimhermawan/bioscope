 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 ml-3 text-gray-800">Test bioscope</h1>
                    <!-- DataTales Example -->
                        <div class="card-body">
                            <div class="table-responsive bg-white p-4">
                                <table class="table table-bordered text-center table-hover" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Durasi</th>
                                            <th>Jumlah soal</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Durasi</th>
                                            <th>Jumlah soal</th>
                                            <th>Status</th>
                                            <th>Action</th>                      
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($p->nama); ?></td>
                                            <td><?php echo e($p->waktu); ?></td>
                                            <td><?php echo e($p->soal); ?></td>
                                            <td>
                                                <span id="status<?php echo e($i); ?>" class="btn badge"><?php echo e($p->keterangan); ?></span>
                                            </td>
                                            <td>
                                                <form method="GET" action="<?php echo e(url('test/result/'.$p->id)); ?>">
                                                    <button type="submit" class="btn badge badge-info p-2">Show</button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <!-- /.container-fluid -->
                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript">
                if ('<?php echo e($p->keterangan); ?>' == 'Tidak Aktif') {
                var belum = document.getElementById('status<?php echo e($loop->iteration); ?>');
                belum.classList.add('badge-danger');
                } else if ('<?php echo e($p->keterangan); ?>' == 'Aktif') {
                var sudah = document.getElementById('status<?php echo e($loop->iteration); ?>');
                sudah.classList.add('badge-success');
                }

                </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/ujian/hasil.blade.php ENDPATH**/ ?>