 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 ml-3 text-gray-800">Test bioscope</h1>
                    <!-- DataTales Example -->
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-center table-hover" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Benar</th>
                                            <th>Salah</th>
                                            <th>kosong</th>
                                            <th>Score</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Benar</th>
                                            <th>Salah</th>
                                            <th>kosong</th>
                                            <th>Score</th>                      
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $id[] = $p->id;?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($p->name); ?></td>
                                            <td><?php echo e($p->quiziz1->where('exam_id', 999)->first()->benar??'--'); ?></td>
                                            <td><?php echo e($p->quiziz1->where('exam_id', 999)->first()->salah??'--'); ?></td>
                                            <td><?php echo e($p->quiziz1->where('exam_id', 999)->first()->kosong??'--'); ?></td>
                                            <td><?php echo e($p->quiziz1->where('exam_id', 999)->first()->score??'--'); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/quiziz/data-hasil.blade.php ENDPATH**/ ?>