<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
</head>
<body>
<iframe src="">
	<h1>Test</h1>
</iframe>
</body>
</html><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/test.blade.php ENDPATH**/ ?>