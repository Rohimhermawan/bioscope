
<?php $__env->startSection('content'); ?>
<div class="container bg-white py-4" style="border-radius: 3px; margin-top: 100px;">
  <div>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
  </div>
  <div>
    <a href="<?php echo e(url('home/kartu-peserta/'.$user->id)); ?>" target="_blank" class="btn badge bg-warning text-align-right">Cetak Kartu Peserta</a>
    <a href="<?php echo e(url('home/identitas/'.$user->id)); ?>" class="btn badge bg-info text-align-right">Edit Biodata</a>
  </div>
  	<div class="col-md-11" id="data" style="margin: auto;">
  		<div class="table-responsive">
  			<table class="table">
  				<tr>
  					<td >Cabang</td>
  					<td >: <?php echo e($user->cabang); ?></td>
  				</tr>
          <tr>
            <td >Sekolah</td>
            <td >: <?php echo e($user->sekolah); ?></td>
          </tr>
  				<tr>
  					<td>Nama Ketua</td>
  					<td>: <?php echo e($user->nama1); ?></td>
  					<td>Nama Anggota</td>
  					<td>: <?php echo e($user->nama2); ?></td>
  					<td>Nama Anggota</td>
  					<td>: <?php echo e($user->nama3); ?></td>
  				</tr>
  				<tr>
  					<td>Domisili (Asal Kota)</td>
  					<td>: <?php echo e($user->domisili1); ?></td>
  					<td>Domisili (Asal Kota)</td>
  					<td>: <?php echo e($user->domisili2); ?></td>
  					<td>Domisili (Asal Kota)</td>
  					<td>: <?php echo e($user->domisili3); ?></td>
  				</tr>
  				<tr>
  					<td>Kelas</td>
  					<td>: <?php echo e($user->kelas1); ?></td>
  					<td>Kelas</td>
  					<td>: <?php echo e($user->kelas2); ?></td>
  					<td>Kelas</td>
  					<td>: <?php echo e($user->kelas3); ?></td>
  				</tr>
  				<tr>
  					<td>Alamat</td>
  					<td>: <?php echo e($user->alamat1); ?></td>
  					<td>Alamat</td>
  					<td>: <?php echo e($user->alamat2); ?></td>
  					<td>Alamat</td>
  					<td>: <?php echo e($user->alamat3); ?></td>
  				</tr>
  				<tr>
  					<td>No. Handphone</td>
  					<td><?php echo e($user->telepon1); ?></td>
  					<td>No. Handphone</td>
  					<td><?php echo e($user->telepon2); ?></td>
  					<td>No. Handphone</td>
  					<td><?php echo e($user->telepon3); ?></td>
  				</tr>
  				<tr>
  					<td>Id Line</td>
  					<td><?php echo e($user->line1); ?></td>
  					<td>Id Line</td>
  					<td><?php echo e($user->line2); ?></td>
  					<td>Id Line</td>
  					<td><?php echo e($user->line3); ?></td>
  				</tr>
  				<tr>
  					<td>Email</td>
  					<td><?php echo e($user->email1); ?></td>
  					<td>Email</td>
  					<td><?php echo e($user->email2); ?></td>
  					<td>Email</td>
  					<td><?php echo e($user->email3); ?></td>
  				</tr>
  				<tr>
  					<td>Foto Diri</td>
  					<td><img src="<?php echo e(asset('storage/foto/'.$user->foto1)); ?>" alt="<?php echo e($user->foto1); ?>" style="width: 300px; height: 400px;"></td>
  					<td>Foto Diri</td>
  					<td><img src="<?php echo e(url('storage/foto/'.$user->foto2)); ?>" alt="<?php echo e($user->foto2); ?>" style="width: 300px; height: 400px;"></td>
  					<td>Foto Diri</td>
  					<td><img src="<?php echo e(url('storage/foto/'.$user->foto3)); ?>" alt="<?php echo e($user->foto3); ?>" style="width: 300px; height: 400px;"></td>
  				</tr>
  				<tr>
  					<td>Kartu Pelajar</td>
  					<td><img src="<?php echo e(url('storage/kartu/'.$user->kartu1)); ?>" alt="<?php echo e($user->kartu1); ?>" style="width: 400px; height: 300px;"></td>
  					<td>kartu pelajar</td>
  					<td><img src="<?php echo e(url('storage/kartu/'.$user->kartu2)); ?>" alt="<?php echo e($user->kartu2); ?>" style="width: 400px; height: 300px;"></td>
  					<td>kartu pelajar</td>
  					<td><img src="<?php echo e(url('storage/kartu/'.$user->kartu3)); ?>" alt="<?php echo e($user->kartu3); ?>" style="width: 400px; height: 300px;"></td>
  				</tr>
  			</table>
  		</div>
  	</div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/user/biodata.blade.php ENDPATH**/ ?>