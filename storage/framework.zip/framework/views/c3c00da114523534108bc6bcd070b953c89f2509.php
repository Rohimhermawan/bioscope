
<?php $__env->startSection('content'); ?>
<div class="container bg-white py-4" style="border-radius: 3px; margin-top: 100px;">
	<div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	</div>
	<div class="table-responsive">
		<table class="table">
			<thead>
				<tr>	
					<td>No</td>
					<td>Nama Test</td>
					<td>Jumlah Soal</td>
					<td>Waktu Ujian (menit)</td>
					<td></td>
				</tr>
			</thead>
		<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tbody>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><?php echo e($p->nama); ?></td>
					<td><?php echo e($p->soal); ?></td>
					<td><?php echo e($p->waktu); ?></td>
					<td>
						<form method="POST" action="<?php echo e(url('exams/'.$p->id)); ?>" id="form">
							<?php echo csrf_field(); ?>
							<button type="submit" class="btn btn-primary btn-pill" id="button<?php echo e($loop->iteration); ?>"></button>
							<a href="#" class="badge btn bg-success" id="tombol<?php echo e($loop->iteration); ?>" hidden></a>
							<script type="text/javascript">
								var btn = document.getElementById('button<?php echo e($loop->iteration); ?>');
								var btn1 = document.getElementById('tombol<?php echo e($loop->iteration); ?>');
								if (<?php echo e($user->answer->where('exam_id', $p->id)->count()); ?>>0) {
									btn.setAttribute('hidden', '');
									btn1.removeAttribute('hidden');
									btn1.innerHTML = 'Sudah Dikerjakan';
								} else {
									btn.innerHTML = 'Kerjakan';
								}
							</script>
						</form>
					</td>
				</tr>
			</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/user/test.blade.php ENDPATH**/ ?>