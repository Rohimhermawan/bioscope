 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Upload Pembayaran</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Cabang</th>
                                            <th>Bukti Pembayaran</th>
                                            <th>Konfirmasi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Cabang</th>
                                            <th>Bukti Pembayaran</th>                                       
                                            <th>Konfirmasi</th>
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($p->name); ?></td>
                                            <td><?php echo e($p->participant[0]->cabang); ?></td>
                                            <td><img src="<?php echo e(asset('storage/pembayaran/'.$p->participant[0]->bukti)); ?>" width="500px"></td>
                                            <td>
                                                <div class="form-switch">
                                                <form method="POST" action="<?php echo e(url('confirm/'.$p->id)); ?>">
                                                  <?php echo csrf_field(); ?>
                                                  <input class="form-check-input ml-2" type="checkbox" id="konfirm<?php echo e($i); ?>" >
                                                    <button type="submit" class=" p-3" style="z-index: 2; margin-right: 30px; opacity: 0;"></button>
                                                </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <script type="text/javascript">
                                            if ('<?php echo e($p->pembayaran); ?>' == 'Sudah Bayar') {
                                                var sudah = document.getElementById('status<?php echo e($i); ?>');
                                                sudah.classList.add('badge-success');
                                                var konfirm = document.getElementById('konfirm<?php echo e($i); ?>');
                                                konfirm.setAttribute("checked","");
                                            }
                                        </script>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/peserta/bukti.blade.php ENDPATH**/ ?>