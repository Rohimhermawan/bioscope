<?php 
use Illuminate\Support\Facades\Auth;
use App\Models\Participant;

$user = auth::user();
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Bioscope</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('user/fonts/icomoon/style.css')); ?>">
    
  <style type="text/css">
    .sembunyi{
      display:none;
    }
  </style>
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300" style=" background-color: #ededed"onload="time()">
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: #555555 ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Bioscope</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link text-white" href="<?php echo e(url('home/pembayaran')); ?>" id="upload" aria-disabled="true">Upload Pembayaran</a>
          <a class="nav-link text-white disabled" aria-current="page" href="<?php echo e(url('home/identitas')); ?>" id="identitas" hidden aria-disabled="true">Tambah Identitas</a>
          <a class="nav-link text-white disabled" aria-current="page" href="<?php echo e(url('home/identitas-peserta')); ?>" id="identitas1" hidden aria-disabled="true">Identitas</a>
          <a class="nav-link text-white disabled" href="#" id="sertif" hidden aria-disabled="true">Sertifikat</a>
          <a class="nav-link text-white disabled" href="<?php echo e(url('exam')); ?>" id="test" hidden aria-disabled="true">Test</a>
        <div >
          <b style="position: absolute; right: 7%; top: 27%; color: white;"><?php echo e($user->name); ?></b>
          <a class="nav-link text-white" style="position: absolute; right: 0%; top: 15%" href="<?php echo e(url('logout')); ?>" aria-disabled="true">Logout</a>
        </div>
        </div>
      </div>
    </div>
  </nav>
    <?php echo $__env->yieldContent('content'); ?> 
  <script type="text/javascript">
    var identitas = document.getElementById('identitas');
    var identitas1 = document.getElementById('identitas1');
    var sertif = document.getElementById('sertif');
    if ('<?php echo e($user->pembayaran); ?>' == 'Sudah Bayar' && '<?php echo e(isset($user->participant[0]->domisili1)); ?>' == '') {
      identitas.classList.remove("disabled");
      identitas.removeAttribute("hidden");
    } 

    if ('<?php echo e(isset($user->participant[0]->domisili1)); ?>') {
      identitas1.classList.remove("disabled");
      identitas1.removeAttribute("hidden");
    var test = document.getElementById('test');
      test.classList.remove("disabled");
      test.removeAttribute("hidden");
    } 
  </script>
  </body>
</html><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/layouts/user.blade.php ENDPATH**/ ?>