 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 ml-3 text-gray-800">Test bioscope</h1>
                    <!-- DataTales Example -->
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-center table-hover" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Score</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Score</th>
                                            <th>Action</th>                      
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $id[] = $p->id;?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($p->name); ?></td>
                                            <td><?php echo e(($p->result->where('exam_id', $kode)->first()->benar)*4 - ($p->result->where('exam_id', $kode)->first()->salah)); ?></td>
                                            <td>
                                                <a href="" class="btn btn-info" data-toggle="modal" data-target="#detail<?php echo e($p->id); ?>">Show</a>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
               <!-- detaile -->
               <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal fade" id="detail<?php echo e($p->id); ?>" tabindex="-99" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($p->id); ?>" style="box-sizing: border-box;" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document" style="width: 800px !important">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Hasil Peserta</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                      <table>
                                                        <tr>
                                                            <td>
                                                        <?php $__currentLoopData = $p->answer->where('exam_id', $kode); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="mx-1" value="<?php echo e($u->hasil); ?>" id="jawaban<?php echo e($p->id); ?><?php echo e($loop->iteration); ?>"><?php echo e($loop->iteration); ?>. <?php echo e($u->jawaban); ?>

                                                                </span>
                                                                <script type="text/javascript">
                                                                var jawaban = document.getElementById('jawaban<?php echo e($p->id); ?><?php echo e($loop->iteration); ?>');
                                                                if ('<?php echo e($u->hasil); ?>' == 'Benar') {
                                                                jawaban.style.color = 'lightgreen';
                                                                } else if ('<?php echo e($u->hasil); ?>' == 'Kosong') {
                                                                    jawaban.style.color = 'yellow';
                                                                } else  {
                                                                jawaban.style.color = 'red';
                                                                }
                                                                </script>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Soal terjawab</td>
                                                            <td>: <?php echo e($p->result->where('exam_id', $kode)->first()->dijawab); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Benar</td>
                                                            <td>: <?php echo e($p->result->where('exam_id', $kode)->first()->benar); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Salah</td>
                                                            <td>: <?php echo e($p->result->where('exam_id', $kode)->first()->salah); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kosong</td>
                                                            <td>: <?php echo e($p->result->where('exam_id', $kode)->first()->kosong); ?></td>
                                                        </tr>
                                                      </table>  
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
var id = [];
for (let i = 0; i < <?php echo e(last($id)); ?>; i++) {
    id.push(i);
}
for (let j = 0; j < id.length; j++) {
    for (let i = 0; i < <?php echo e($exams->jumlah); ?>; i++) {
        var jawaban = document.getElementById('jawaban'j+i);
        var nilai = jawaban.value;
            if (nilai == 'Benar') {
                jawaban.style.color = 'lightgreen';
            } else if (nilai == 'Kosong') {
                jawaban.style.color = 'yellow';
            } else  {
                jawaban.style.color = 'red';
            }    
    }
}
</script>                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/ujian/data-hasil.blade.php ENDPATH**/ ?>