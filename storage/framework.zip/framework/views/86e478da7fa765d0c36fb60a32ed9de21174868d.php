 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session('delete')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('delete')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session('update')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('update')); ?>

                    </div>
                    <?php endif; ?>
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Test bioscope</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a class="m-0 font-weight-bold text-white btn btn-dark" href="<?php echo e(url('test/create')); ?>">Tambah Ujian</a>
                            <a class="m-0 font-weight-bold text-white btn btn-secondary" href="<?php echo e(url('soal/create')); ?>">Tambah Soal</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered text-center table-hover" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Durasi</th>
                                            <th>Jumlah soal</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                            <th>Soal</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Durasi</th>
                                            <th>Jumlah soal</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                            <th>Soal</th>                      
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($p->nama); ?></td>
                                            <td><?php echo e($p->waktu); ?></td>
                                            <td><?php echo e($p->soal); ?></td>
                                            <td>
                                                <form method="GET" action="<?php echo e(url('test/'.$p->id)); ?>">
                                                <button class="btn badge badge-warning p-2">Edit</button>
                                                </form>
                                                <hr>
                                                <a class="btn badge badge-danger p-2" data-toggle="modal" data-target="#deleteModal<?php echo e($p->id); ?>">Delete</a>
                                            </td>
                                            <td> 
                                                <span id="status<?php echo e($i); ?>" class="btn badge"><?php echo e($p->keterangan); ?></span>
                                                <div class="form-check form-switch">
                                                    <form method="GET" action="<?php echo e(url('test/active/'.$p->id)); ?>">
                                                        <input class="form-check-input ml-2" type="checkbox" id="konfirm<?php echo e($i); ?>" >
                                                        <button type="submit" class=" p-3" style="z-index: 2; margin-right: 30px; opacity: 0;"></button>
                                                    </form>
                                                </div>
                                            </td>
                                            <td>
                                                <form method="GET" action="<?php echo e(url('soal/'.$p->id)); ?>">
                                                	<button type="submit" class="btn badge badge-info p-2">Show</button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
                <!-- Sure Modal-->
                <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="deleteModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Ready to Delete?</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">Select "Delete" below if you are ready to delete your current test.</div>
                            <div class="modal-footer">
                                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                <form action="<?php echo e(url('test/'.$p->id)); ?>" method="POST">
                                <button class=" btn btn btn-danger p-2">Delete</button>
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>     
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script type="text/javascript">
                if ('<?php echo e($p->keterangan); ?>' == 'Tidak Aktif') {
                var belum = document.getElementById('status<?php echo e($loop->iteration); ?>');
                belum.classList.add('badge-danger');
                } else if ('<?php echo e($p->keterangan); ?>' == 'Aktif') {
                var sudah = document.getElementById('status<?php echo e($loop->iteration); ?>');
                sudah.classList.add('badge-success');
                var konfirm = document.getElementById('konfirm<?php echo e($loop->iteration); ?>');
                konfirm.setAttribute("checked","");
                }

                </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/ujian/index.blade.php ENDPATH**/ ?>