 
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Peserta bioscope</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a class="m-0 font-weight-bold text-primary">belum Bayar</a>
                            <a href="m-0 font-weight-bold text-primary">Sudah bayar</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Status</th>
                                            <th>Region</th>
                                            <th>Email</th>
                                            <th>No. Handphone</th>
                                            <th>Detail</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Status</th>
                                            <th>Region</th>
                                            <th>Email</th>
                                            <th>No. Handphone</th>
                                            <th>Detail</th>                                       
                                    </tfoot>
                                    <tbody>
                                        <?php $i=1; ?>
                                        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($p->nama1); ?></td>
                                            <td><?php echo e($p->bayar); ?></td>
                                            <td><?php echo e($p->cabang); ?></td>
                                            <td><?php echo e($p->email1); ?></td>
                                            <td><?php echo e($p->telepon1); ?></td>
                                            <td>
                                                <a class="btn btn-info" href="" data-toggle="modal" data-target="#detail<?php echo e($p->id); ?>">
                                                Show
                                                </a>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
                <!-- detaile -->
                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal fade" id="detail<?php echo e($p->id); ?>" tabindex="-99" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($p->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable" role="document" width="80%">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Biodata Peserta</h5>
                                                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                      <table>
                                                        <tr>
                                                            <td>Nama Ketua</td>
                                                            <td>: <?php echo e($p->nama1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sekolah</td>
                                                            <td>: <?php echo e($p->sekolah1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($p->kelas1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($p->alamat1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($p->telepon1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($p->nilai1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($p->email1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>foto</td>
                                                            <td>: <?php echo e($p->foto1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>kartu</td>
                                                            <td>: <?php echo e($p->kartu1); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Nama anggota</td>
                                                            <td>: <?php echo e($p->nama2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sekolah</td>
                                                            <td>: <?php echo e($p->sekolah2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($p->kelas2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($p->alamat2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($p->telepon2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($p->nilai2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($p->email2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>foto</td>
                                                            <td>: <?php echo e($p->foto2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>kartu</td>
                                                            <td>: <?php echo e($p->kartu2); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Nama anggota</td>
                                                            <td>: <?php echo e($p->nama3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Sekolah</td>
                                                            <td>: <?php echo e($p->sekolah3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Kelas</td>
                                                            <td>: <?php echo e($p->kelas3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>Alamat</td>
                                                            <td>: <?php echo e($p->alamat3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>telepon</td>
                                                            <td>: <?php echo e($p->telepon3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>line</td>
                                                            <td>: <?php echo e($p->nilai3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>email</td>
                                                            <td>: <?php echo e($p->email3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>foto</td>
                                                            <td>: <?php echo e($p->foto3); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td>kartu</td>
                                                            <td>: <?php echo e($p->kartu3); ?></td>
                                                        </tr>
                                                      </table>  
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\OneDrive - Universitas Padjadjaran\Documents\Coding\New folder\htdocs\AdminBioscope\resources\views/admin/data-peserta.blade.php ENDPATH**/ ?>